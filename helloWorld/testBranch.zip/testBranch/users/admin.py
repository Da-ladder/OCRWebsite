from django.contrib import admin

from .models import *

admin.site.register(User)
admin.site.register(Club)
admin.site.register(ClubTag)


# Register your models here.
