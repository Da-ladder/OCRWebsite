import os

import sys

import site

from django.core.wsgi import get_wsgi_application

# Add the app’s directory to the PYTHONPATH

sys.path.append(r'C:\Users\zcody\OneDrive\Documents\Coding Club\OCRWebsite-1\helloWorld\testBranch')

sys.path.append(r'C:\Users\zcody\OneDrive\Documents\Coding Club\OCRWebsite-1\helloWorld\testBranch\testBranch')

os.environ['DJANGO_SETTINGS_MODULE'] = 'testBranch.settings'

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'testBranch.settings')

application = get_wsgi_application()

